import numpy as np
import random as random
import torch
import copy
import argparse
from models.Semi_ComGRL import ComGRL

parser = argparse.ArgumentParser()

parser = argparse.ArgumentParser()   # 服务器也是146

parser.add_argument('--dataset', type=str, default='CiteSeer', help='dataset used.')
parser.add_argument('--r1', type=float, default=0.1, help='hyparameter in loss function.')  # 这个是0.1，其他不变，就是最好的效果73.59,现在试试0.05
parser.add_argument('--tau', type=float, default=0.7, help='hyparameter in contrastive loss.') # 0.7- 73.59  0.5-72.95  1.3-72.14  1.5-71.31
parser.add_argument('--order', type=int, default=4, help='number of multi-hop graph.')
parser.add_argument('--nb_epochs', type=int, default=1000, help='maximal epochs.')  # 5000
parser.add_argument('--patience', type=int, default=70, help='early stop.')
parser.add_argument('--nheads', type=int, default=8, help='number of heads in self-attention.')
parser.add_argument('--Trans_layer_num', type=int, default=2, help='layers number for self-attention.')
parser.add_argument('--lr', type=float, default=0.0003, help='learning ratio.')
parser.add_argument('--MLPdim', type=int, default=128, help='hidden dimension.')
parser.add_argument('--trans_dim', type=int, default=128, help='hidden dimension for transformer.')
parser.add_argument('--dropout_att', type=float, default=0.4, help='dropout in self-attention layers.')
parser.add_argument('--random_aug_feature', type=float, default=0.4, help='dropout in hidden layers.')
parser.add_argument('--wd', type=float, default=5e-4, help='weight delay.')
parser.add_argument('--act', type=str, default='leakyrelu', help='hidden action.')
# for noise generation
parser.add_argument('--lab_noi_rat', type=float, default=0.0, help='noise ratio for label.')
parser.add_argument('--noise', type=str, default='uniform', help='the type for label noise generation.')
parser.add_argument('--gra_noi_rat', type=float, default=0.0, help='noise ratio for graph.')
parser.add_argument('--pres_label', type=bool, default=False, help='indicate whether original lables are preserved in the psuedo labels')
parser.add_argument('--warmup_num', type=int, default=100, help='epoch for warm-up.')
parser.add_argument('--IsLabNoise', type=bool, default=True, help='indicate the use of label-self-improvement')
parser.add_argument('--SamSe', type=bool, default=False, help='indicate the use of node selection.')
parser.add_argument('--P_sel', type=float, default=0.9, help='ratio to preserve 1-0.9 pseudo labels.')
parser.add_argument('--P_sel_onehot', type=float, default=0.97, help='ratio to preserve 1-0.9 one-hot label.')
parser.add_argument('--IsGraNoise', type=bool, default=True, help='is there label noise')
parser.add_argument('--P_gra_sel', type=float, default=0.99, help='ratio for preserve 1-0.99 edges for pseudo graph.')


args = parser.parse_args()
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

if __name__ == '__main__':
    if torch.cuda.is_available():
        args.device = torch.device('cuda:0')
    else:
        args.device = torch.device('cpu')

    ACC_seed = []
    Time_seed = []  # 2034  2017:75.3  2013:74.6  2011:47.6  2009: 74.5  2003: 74.6  2000:74.6  1993:75
    seed = 2017
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    embedder = ComGRL(copy.deepcopy(args))
    test_acc, training_time, stop_epoch = embedder.training()
    ACC_seed.append(test_acc)
    Time_seed.append(training_time)
    torch.cuda.empty_cache()
    ACC_seed = np.array(ACC_seed)*100

    print("-->ACC %.4f  -->STD is: %.4f" %(np.mean(ACC_seed), np.std(ACC_seed)))
