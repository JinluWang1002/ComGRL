import time
from models.embedder import embedder_single
import torch.nn.functional as F
import torch
import torch.nn as nn
import copy
import numpy as np

def row_normalize(A):
    """Row-normalize dense matrix"""
    eps = 2.2204e-16
    rowsum = A.sum(dim=-1).clamp(min=0.) + eps
    r_inv = rowsum.pow(-1)
    A = r_inv.unsqueeze(-1) * A
    return A

def Ncontrast(x_dis, adj_label, tau = 1, train_index_sort=None):
    x_dis = torch.exp(tau * x_dis)
    x_dis_sum_mid = torch.sum(x_dis, 1)
    x_dis_sum_pos_mid = torch.sum(x_dis *  adj_label, 1)
    x_dis_sum = x_dis_sum_mid[train_index_sort]
    x_dis_sum_pos = x_dis_sum_pos_mid[train_index_sort]
    loss = -torch.log(x_dis_sum_pos * (x_dis_sum**(-1))+1e-8).mean()
    return loss

def get_A_r(adj, r):
    adj_label = adj
    for i in range(r - 1):
        adj_label = adj_label @ adj
    return adj_label


class FeedForward(nn.Module):
    def __init__(self, d_model, d_ff=2048, dropout=0.1):
        super().__init__()

        # We set d_ff as a default to 2048
        self.linear_1 = nn.Linear(d_model, d_ff)
        self.dropout = nn.Dropout(dropout)
        self.linear_2 = nn.Linear(d_ff, d_model)

    def forward(self, x):
        x = self.dropout(F.relu(self.linear_1(x)))
        x = self.linear_2(x)
        return x


class EfficientAttention(nn.Module):

    def __init__(self, in_channels, key_channels, head_count, value_channels):
        super().__init__()
        self.in_channels = in_channels
        self.key_channels = key_channels
        self.head_count = head_count
        self.value_channels = value_channels

        self.keys = nn.Linear(in_channels, key_channels)
        self.queries = nn.Linear(in_channels, key_channels)
        self.values = nn.Linear(in_channels, value_channels)
        self.reprojection = nn.Linear(key_channels, key_channels)

    def forward(self, input_):
        keys = self.keys(input_)
        queries = self.queries(input_)
        values = self.values(input_)
        head_key_channels = self.key_channels // self.head_count
        head_value_channels = self.value_channels // self.head_count

        attended_values = []
        for i in range(self.head_count):
            key = F.softmax(keys[:,i * head_key_channels: (i + 1) * head_key_channels], dim=0)
            query = F.softmax(queries[:,i * head_key_channels: (i + 1) * head_key_channels], dim=1)
            value = values[:,i * head_value_channels: (i + 1) * head_value_channels]
            context = key.transpose(0, 1) @ value
            attended_value = query @context
            attended_values.append(attended_value)

        aggregated_values = torch.cat(attended_values, dim=1)
        attention = self.reprojection(aggregated_values)
        return attention


class Norm(nn.Module):
    def __init__(self, d_model, eps=1e-6):
        super().__init__()

        self.size = d_model

        # create two learnable parameters to calibrate normalisation
        self.alpha = nn.Parameter(torch.ones(self.size))
        self.bias = nn.Parameter(torch.zeros(self.size))

        self.eps = eps

    def forward(self, x):
        norm = self.alpha * (x - x.mean(dim=-1, keepdim=True)) \
               / (x.std(dim=-1, keepdim=True) + self.eps) + self.bias
        return norm

def get_feature_dis(x):
    """
    x :           batch_size x nhid
    x_dis(i,j):   item means the similarity between x(i) and x(j).
    """
    x_dis = x@x.T
    mask = torch.eye(x_dis.shape[0]).to(x.device)
    x_sum = torch.sum(x**2, 1).reshape(-1, 1)
    x_sum = torch.sqrt(x_sum).reshape(-1, 1)
    x_sum = x_sum @ x_sum.T
    x_dis = x_dis*(x_sum**(-1))
    x_dis = (1-mask) * x_dis
    return x_dis

def get_clones(module, N):
    return nn.ModuleList([copy.deepcopy(module) for i in range(N)])

class EncoderLayer(nn.Module):
    def __init__(self, args, d_model, heads, dropout=0.1):
        super().__init__()
        self.args = args
        self.norm_1 = Norm(d_model)
        self.norm_2 = Norm(d_model)
        self.effectattn = EfficientAttention(in_channels = d_model, key_channels =d_model, head_count =heads, value_channels = d_model)  #  注意力机制
        self.ff = FeedForward(d_model, dropout=dropout)
        self.dropout_1 = nn.Dropout(dropout)
        self.dropout_2 = nn.Dropout(dropout)

    def forward(self, x):
        x2 = self.norm_1(x)
        x_pre = self.effectattn(x2)
        x = x + x_pre
        x2 = self.norm_2(x)
        x = x + self.dropout_2(self.ff(x2))
        return x


class ComGRL_model(nn.Module):
    def __init__(self, arg):
        super(ComGRL_model, self).__init__()

        self.dropout = arg.random_aug_feature
        self.Trans_layer_num = arg.Trans_layer_num  # transformer的层
        self.layers = get_clones(EncoderLayer(arg, arg.trans_dim , arg.nheads, arg.dropout_att), self.Trans_layer_num)  #  EncoderLayer是自注意力的模块
        self.norm_input = Norm(arg.ft_size)
        self.MLPfirst = nn.Linear(arg.ft_size,arg.trans_dim)
        self.MLPlast = nn.Linear(arg.trans_dim,arg.nclasses)
        self.norm_layer = Norm(arg.trans_dim)


    def forward(self, x_input):
        x_input = self.norm_input(x_input)
        x = self.MLPfirst(x_input)
        x = F.dropout(x, self.dropout, training=self.training)
        x_dis = get_feature_dis(self.norm_layer(x))
        for i in range(self.Trans_layer_num):
            x = self.layers[i](x)   # self.transformer

        CONN_INDEX = F.relu(self.MLPlast(x))

        return F.softmax(CONN_INDEX, dim=1), x_dis


class EncoderLayer(nn.Module):
    def __init__(self, args, d_model, heads, dropout=0.1):
        super().__init__()
        self.args = args
        self.norm_1 = Norm(d_model)
        self.norm_2 = Norm(d_model)
        self.effectattn = EfficientAttention(in_channels = d_model, key_channels =d_model, head_count =heads, value_channels = d_model)  #  注意力机制
        self.ff = FeedForward(d_model, dropout=dropout)
        self.dropout_1 = nn.Dropout(dropout)
        self.dropout_2 = nn.Dropout(dropout)

    def forward(self, x):
        x2 = self.norm_1(x)
        x_pre = self.effectattn(x2)
        x = x + x_pre
        x2 = self.norm_2(x)
        x = x + self.dropout_2(self.ff(x2))
        return x



class ComGRL(embedder_single):
    def __init__(self, args):
        embedder_single.__init__(self, args)
        self.args = args
        self.args.nclasses = (self.labels.max() - self.labels.min() + 1).item()
        self.model = ComGRL_model(self.args).to(self.args.device)
        self.temp = 0.3
        self.alpha = 1.0


    def _generate_lam(self):
        if self.alpha > 0.:
            return np.random.beta(self.alpha, self.alpha)
        else:
            return 1.

    def extract_keys_by_value(self, unreach_dict):

        key_groups = {i: [] for i in range(1, 8)}


        for key, value in unreach_dict.items():
            if value in key_groups:
                key_groups[value].append(key)

        tensors = {i: torch.tensor(key_groups[i]) for i in range(1, 8)}
        return tensors


    def group_indices_by_value(self,labels):

        idx_dict = {i + 1: [] for i in range(torch.max(labels).item() + 1)}  # 创建从1到7的键

        for idx, value in enumerate(labels):
            idx_dict[int(value) + 1].append(idx)

        tensors = {k: torch.tensor(v) for k, v in idx_dict.items()}
        return tensors


    def find_unique_ones(self,tensor_rounded):
        ones_indices = torch.nonzero(tensor_rounded == 1, as_tuple=False)
        used_rows = set()
        used_cols = set()

        unique_indices = []
        for idx in ones_indices:
            row, col = idx[0].item(), idx[1].item()

            if row in used_rows or col in used_cols:
                continue

            unique_indices.append([row, col])
            used_rows.add(row)
            used_cols.add(col)

        if unique_indices:
            result = torch.tensor(unique_indices).t()
        else:
            result = torch.empty((2, 0), dtype=torch.long)
        return result


    def sharpen(self,logs, temp):
        val = (torch.pow(logs, 1. / temp) / torch.sum(torch.pow(logs, 1. / temp), dim=1, keepdim=True)).detach()
        val[val.isnan()] = 1e-16
        return val

    def compute_cosine_similarity(self,matrix1, matrix2):
        # 归一化
        norm1 = matrix1 / matrix1.norm(dim=1, keepdim=True)
        norm2 = matrix2 / matrix2.norm(dim=1, keepdim=True)

        # 计算余弦相似度
        similarity_matrix = torch.mm(norm1, norm2.t())
        return similarity_matrix


    def neighbour_distribution(self, y, adj):
        import torch_scatter
        #row, col = adj  # adj的行索引,列索引
        row = adj.row
        col = adj.col
        row = torch.tensor(row, dtype=torch.int32)
        col = torch.tensor(col, dtype=torch.int32)
        row = row.to(torch.long)
        col = col.to(torch.long)
        row = row.to(self.args.device)
        col = col.to(self.args.device)
        nb_dist = torch_scatter.scatter_mean(y[col], row, dim=0, dim_size=y.shape[0]).detach()
        self.nb_dist = self.sharpen(nb_dist, temp=self.temp)
        return self.nb_dist


    def training(self):

        features = self.features.to(self.args.device)
        graph_org = self.dgl_graph.to(self.args.device)
        self.graph_org_torch = self.adj_list[0].to(self.args.device)  # A+I(norm)

        print("Started training...")
        optimiser = torch.optim.Adam(self.model.parameters(), lr=self.args.lr, weight_decay = self.args.wd)

        label_orig = self.labels.clone()
        if self.idx_train.dtype == torch.bool:
            self.idx_train = torch.where(self.idx_train == 1)[0]
            self.idx_val = torch.where(self.idx_val == 1)[0]
            self.idx_test = torch.where(self.idx_test == 1)[0]

        self.label_ori = self.labels.clone()

        train_lbls = self.label_ori[self.idx_train]
        val_lbls = self.label_ori[self.idx_val]
        test_lbls = self.label_ori[self.idx_test]

        self.idx_train_ori = self.idx_train.clone()

        ones = torch.sparse.torch.eye(self.args.nclasses).to(self.args.device)
        self.labels_oneHot = ones.index_select(0, self.labels)

        if self.args.pres_label:  # 执行else
            train_unsel = torch.cat((self.idx_val, self.idx_test), dim=0)
        else:
            train_unsel = torch.cat((self.idx_train,self.idx_val, self.idx_test), dim=0)

        train_all_pos_bool = torch.ones(self.labels.size(0))
        train_all_pos_bool[train_unsel] = 0
        train_all_pos = train_all_pos_bool.to(self.args.device)

        best = 1e-9
        output_acc = 1e-9
        stop_epoch = 0
        start = time.time()
        totalL = []
        test_acc_list = []

        PP = 0

        for epoch in range(self.args.nb_epochs):
            self.model.train()
            optimiser.zero_grad()
            embeds_tra, x_dis = self.model(features)
            loss_cla = F.cross_entropy(embeds_tra[self.idx_train], self.labels_oneHot[self.idx_train])

            max_va_pos = embeds_tra.max(1)[0]
            max_va_pos_index = max_va_pos >= PP

            adj_label = get_A_r(self.graph_org_torch, self.args.order)
            loss_Ncontrast = Ncontrast(x_dis, adj_label, tau=self.args.tau,
                                       train_index_sort=max_va_pos_index)
            loss = loss_cla + self.args.r1 * loss_Ncontrast

            loss.backward()
            optimiser.step()


            ################STA|Eval|###############
            if epoch % 5 == 0 and epoch != 0:
                totalL.append(loss.item())
                self.model.eval()  # 验证模式

                embeds, _ = self.model(features)
                val_acc = accuracy(embeds[self.idx_val], val_lbls)
                test_acc = accuracy(embeds[self.idx_test], test_lbls)
                print("{:.4f}|".format(test_acc.item()), end="") if epoch % 50 != 0 else print("{:.4f}|".format(test_acc.item()))

                test_acc_list.append(test_acc.item())
                # early stop
                stop_epoch = epoch
                if val_acc > best:
                    best = val_acc
                    output_acc = test_acc.item()


                    if epoch > self.args.warmup_num:
                        max_va_pos_class = embeds_tra.max(1)[1]+1
                        unreach_dict = dict(zip(self.unreach_nodes.tolist(), max_va_pos_class[self.unreach_nodes].tolist()))
                        unreach_dict_class_idx = self.extract_keys_by_value(unreach_dict)
                        train_dict_class_idx = self.group_indices_by_value(self.labels[self.idx_train])

                        train_idx_set = set(self.idx_train.cpu().numpy())
                        is_in_train_idx = torch.tensor([i in train_idx_set for i in self.idx_all.cpu().numpy()],
                                                       device=self.args.device)
                        un_idx = self.idx_all[~is_in_train_idx]
                        self.labels_ori = self.labels_ori.to(dtype=torch.float)
                        self.labels_ori[un_idx] = embeds_tra[un_idx]

                        neibor_distribute = self.neighbour_distribution(self.labels_ori, self.adj_list[2])

                        for key in unreach_dict_class_idx:
                            if key in train_dict_class_idx:
                                unreach_tensor = unreach_dict_class_idx[key]
                                train_tensor = train_dict_class_idx[key]
                                unreach_tensor = unreach_tensor.to(torch.long)

                                unreach_subset = neibor_distribute[unreach_tensor]
                                train_tensor = train_tensor.long()
                                train_subset = neibor_distribute[train_tensor]
                                similarity_neigbor = self.compute_cosine_similarity(unreach_subset, train_subset)

                                tensor_rounded = torch.round(similarity_neigbor * 100) / 100

                                result = self.find_unique_ones(tensor_rounded)
                                unreach_mix = unreach_tensor[result[0]]
                                train_mix = train_tensor[result[1]]
                                #label_ = self.labels_ori[unreach_mix]
                                lam = self._generate_lam()
                                features[train_mix, :] = lam * features[train_mix, :] + (1 - lam) * features[unreach_mix, :]
                                self.labels_oneHot[train_mix, :] = lam * self.labels_oneHot[train_mix, :] + (1 - lam) * self.labels_oneHot[unreach_mix, :]
                                if unreach_mix.shape[0] > 0 :
                                    row = lam * self.graph_org_torch[train_mix, :] + (1 - lam) * self.graph_org_torch[unreach_mix, :]
                                    col = lam * self.graph_org_torch[:, train_mix] + (1 - lam) * self.graph_org_torch[:, unreach_mix]
                                    self.graph_org_torch[train_mix, :], self.graph_org_torch[:, train_mix] = row, col

            ################END|Eval|###############

        training_time = time.time() - start
        print("\n [Classification] ACC: {:.4f} | stop_epoch: {:}| training_time: {:.4f} \n".format(
            output_acc, stop_epoch, training_time))


        return output_acc, training_time, stop_epoch

def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)